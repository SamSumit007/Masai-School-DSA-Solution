if(n**3>m**2)
{
    console.log("true");
}
else
{
    console.log("false");
}