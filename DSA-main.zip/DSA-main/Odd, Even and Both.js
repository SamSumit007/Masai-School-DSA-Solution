if(one%2==0 && two%2==0)
{
    console.log("Even");
}
else if(one%2!=0 && two%2!=0)
{
    console.log("Odd");
}
else
{
    console.log("Even-Odd");
}