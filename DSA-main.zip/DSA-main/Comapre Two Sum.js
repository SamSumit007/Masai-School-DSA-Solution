if((one+two)>three && (four+five)>six)
{
    console.log("Yes");
}
else
{
    console.log("No");
}