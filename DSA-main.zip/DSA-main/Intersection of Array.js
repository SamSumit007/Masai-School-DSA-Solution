//check common element in given 2 arrays

for(var i=0;i<arr1.length;i++)
{
    for(var j=0;j<arr2.length;j++)
    {
        if(arr1[i]==arr2[j])
        {
            console.log(arr1[i]);
        }
    }
}