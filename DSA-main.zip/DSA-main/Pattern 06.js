// 1
// 1
// 2
// 1
// 2
// 3
// pattern like this

var num = 5;

for(var i=1; i<=num; i++)
{
  for(var j=1; j<=i; j++)
  {
    console.log(j);
  }
}