// N=4
//1 2 3 4
//1 2 3 4
//1 2 3 4
//1 2 3 4
// till N

for(var i=1;i<=N;i++)
{
    var bag="";
    for(var j=1;j<=N;j++)
    {
        bag+=j+" ";
    }
    console.log(bag);
}