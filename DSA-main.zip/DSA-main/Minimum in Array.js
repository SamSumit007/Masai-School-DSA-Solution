var min = array[0];
for(var i=0;i<array.length;i++)
{
    if(min>array[i])
    {
        min=array[i];
    }
}
console.log(min);