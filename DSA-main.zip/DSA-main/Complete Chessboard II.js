// You're given a N*N chessboard which initially has some queens present at some of the places on the chessboard. Find if you can place N queens on the chessboard such that no queen can attack any other queen. An empty cell is shown by '.' and a queen is shown by 'Q'.

