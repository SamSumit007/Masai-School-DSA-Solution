for(var i=0;i<arr.lenght;i++)
{
    var bag="";
    for(var j=0;j<arr[i].length;j++)
    {
        bag+= arr[i][j];
    }
    console.log(bag);
}
