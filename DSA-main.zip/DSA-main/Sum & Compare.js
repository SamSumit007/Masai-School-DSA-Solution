if((one+two+three)>(four+five))
{
    console.log("true");
}
else
{
    console.log("false");
}