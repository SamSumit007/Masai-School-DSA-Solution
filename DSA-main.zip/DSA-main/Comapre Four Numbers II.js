if(one>two || three>four)
{
    console.log("Yes");
}
else
{
    console.log("No");
}