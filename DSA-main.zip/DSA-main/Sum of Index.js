for(var i=0;i<arr.length;i++)
{
    var sum=0;
    for(var j=0;j<arr.length;j++)
    {
        sum+=i+j;
    }
    console.log(sum);
}