// all even numbers till N start from 2
var i=2;
while(i<=N);
{
    console.log(i);
    i+=2;
}