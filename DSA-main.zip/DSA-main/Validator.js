// Maze generation algorithmare very famous ways of generating a maze to solve. You have been asked by your friend Noddy to validate the generated maze. A maze is correct iff

// - The maze has exactly one entry point and exactly one exit point (exactly 2 openings in the edges)

// **    and**

// - there must be at least one path from the entry point to the exit point.

