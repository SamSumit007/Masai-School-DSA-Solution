// You are a fan of Masai School and hence you want to write a program that checks for the presence of the string "masaischool" in a 2d array.

// There is a path from any cell of the 2d array to all its neighbouring cells.

// Given 2d arrays, your task is to find if the string is present or not if all the cells in the matrix are connected to all its neighbouring cells.

