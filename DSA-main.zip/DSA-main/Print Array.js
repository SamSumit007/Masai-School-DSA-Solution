//array elements in different lines

for(var i=0;i<Array.length;i++)
{
    console.log(Array[i]);
}