// father age is double and 10 years extra from anna's age

console.log((age*2)+10);