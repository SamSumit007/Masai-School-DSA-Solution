if(number%4==0)
{
    console.log("Yes");
}
else
{
    console.log("No");
}