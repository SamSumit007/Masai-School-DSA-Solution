var sum=0;
var i=1;
while(i<=N)
{
    if(i%2!=0)
    {
        sum+=i;
    }
    i++;
}
console.log(sum);