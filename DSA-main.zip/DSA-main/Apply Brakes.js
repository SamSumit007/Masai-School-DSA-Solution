// speed = distance/time
if((distance/time)>40)
{
    console.log("Apply Brake");
}
else
{
    console.log("Keep Going");
}