//0000   0123
//1111   0123
//2222   0123
//3333   0123

for(var i=0;i<C;i++)
{
    var bag="";
    for(var j=0;j<R;j++)
    {
        bag+=arr[j][i]+" ";
    }
    console.log(bag);
}
