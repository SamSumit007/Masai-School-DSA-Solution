var int=0;
for(var i=arr.length-1;i>=0;i--)
{
    int=(int*10)+arr[i];
}
console.log(int);