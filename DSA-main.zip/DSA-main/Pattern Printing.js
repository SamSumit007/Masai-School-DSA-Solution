//N=3
//*
//* *
//* * *
//till N

for(var i=1;i<=N;i++)
{
    var bag="";
    for(var j=1;j<=i;j++)
    {
        bag+="*"+" ";
    }
    console.log(bag);
}