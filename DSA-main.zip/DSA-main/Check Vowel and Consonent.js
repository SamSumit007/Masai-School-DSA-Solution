// vowels and consonants
var char = "a";

if(char=="a"||char=="A"||char=="e"||char=="E"||char=="i"||char=="I"||char=="o"||char=="O"||char=="u"||char=="U")
{
  console.log("Vowel");
}
else
{
  console.log("Consonant");
}