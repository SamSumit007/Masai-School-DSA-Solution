//method 1
arr.sort(function(a,b){return a-b});

//method 2
arr.sort((a,b)=>a-b);
