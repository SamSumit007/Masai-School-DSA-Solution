// Function for Swaping things in Array

function swap (array,a,b)
{
    temp = array[a];
    array[a] = array[b];
    array[b] = temp;
}