//excluding B
while(A<B)
{
    console.log(A);
    A++;
}