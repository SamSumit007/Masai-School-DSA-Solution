//N=3
//1
//1
//2
//1
//2
//3
//till N

for(var i=1;i<=N;i++)
{
    for(var j=1;j<=i;j++)
    {
        console.log(j);
    }
}