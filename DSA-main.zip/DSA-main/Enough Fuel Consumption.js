// required = fuel*distance
if((fuel*distance)>50)
{
    console.log("Enough");
}
else
{
    console.log("Go On");
}