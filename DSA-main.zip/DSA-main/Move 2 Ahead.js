// Start from 1 till N Odd Nnumbers
var i=1;
while(i<=N)
{
    console.log(i);
    i+=2;
}