if(x==0)
{
    console.log("zero");
}
else if(x==1)
{
    console.log("one");
}
else if(x==2)
{
    console.log("two");
}
else if(x==3)
{
    console.log("three");
}
else if(x==4)
{
    console.log("four");
}
else if(x==5)
{
    console.log("five");
}
else if(x==6)
{
    console.log("six");
}
else if(x==7)
{
    console.log("seven");
}
else if(x==8)
{
    console.log("eight");
}
else if(x==9)
{
    console.log("nine");
}