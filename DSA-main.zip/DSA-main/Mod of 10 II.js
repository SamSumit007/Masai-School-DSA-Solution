var i=1;
while(i<=N)
{
    console.log((i%10));
    i++;
}