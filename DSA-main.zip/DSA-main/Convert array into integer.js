//array is given

var int=0;
for(var i=0;i<arr.length;i++)
{
    int=(int*10)+arr[i];
}
console.log(int);