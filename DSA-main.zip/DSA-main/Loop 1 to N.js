var a=1;
while(a<=N)
{
    console.log(a);
    a++;
}