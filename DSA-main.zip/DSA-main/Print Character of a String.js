//string is given
for(var i=0;i<str.length;i++)
{
    console.log(str[i]);
}