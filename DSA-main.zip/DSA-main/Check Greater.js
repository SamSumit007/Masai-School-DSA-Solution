// true if A>B && C>D

if(A>B&&C>D)
{
    console.log("true");
}
else
{
    console.log("false");
}