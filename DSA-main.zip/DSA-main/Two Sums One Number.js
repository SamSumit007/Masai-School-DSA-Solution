if((one+two)>five && (three+four)>five)
{
    console.log("Yes");
}
else
{
    console.log("No");
}