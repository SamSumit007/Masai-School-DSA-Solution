//[10,num] with difference of 10


for(var i=0;i<=Number;i+=10)
{
    console.log(i);
}