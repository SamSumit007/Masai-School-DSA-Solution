if(Australia>England)
{
    console.log("Australia");
}
else if(England>Australia)
{
    console.log("England");
}
else if(England==Australia)
{
    console.log("Tie");
}