if(((a+b)*c)>(d+e+f+g))
{
    console.log("true");
}
else
{
    console.log("false");
}