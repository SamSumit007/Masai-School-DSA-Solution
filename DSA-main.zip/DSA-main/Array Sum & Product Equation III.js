var sum=0;
var product=1;
for(var i=0;i<N;i++)
{
    sum+=arr[i];
    product*=arr[i];
}
console.log((7*sum)+(9*product));