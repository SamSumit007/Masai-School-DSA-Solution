//even elements from array that is given
var evenarr=[];
for(var i=0;i<array.length;i++)
{
    if(array[i]%2==0)
    {
        evenarr.push(array[i]);
    }
}
console.log(evenarr);