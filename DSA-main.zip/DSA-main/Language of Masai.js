if(str[0]=="a"||str[0]=="e"||str[0]=="i"||str[0]=="o"||str[0]=="u")
{
    console.log("masai"+str);
}
else
{
    console.log(str+"school");
}