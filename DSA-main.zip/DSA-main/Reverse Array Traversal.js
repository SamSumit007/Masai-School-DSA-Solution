var rev=[];
for(var i =array.length-1;i>=0;i--)
{
    rev.push(array[i]);
}
console.log(rev);