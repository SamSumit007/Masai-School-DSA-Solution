// num , K is given
// find all numbers from 1 till N which is Divisible by K
for(var i=1;i<=Number;i++)
{
    if(i%K==0)
    {
        console.log(i);
    }
}