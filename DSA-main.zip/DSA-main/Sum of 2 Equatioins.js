//X=a*5 + b*3
//Y=a*7 + b*4
// print X+Y if a,b is given

console.log(((a*5)+(b*3))+((a*7)+(b*4)));