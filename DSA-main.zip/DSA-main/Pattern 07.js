// 1
// 2
// ******
// 1
// 2
// ******
// 1
// 2
// *******
// pattern like this

var num = 5;

for(var i=1; i<=num; i++)
{
  for(var j=1; j<=num; j++)
  {
    console.log(j);
  }
  console.log("********")
}