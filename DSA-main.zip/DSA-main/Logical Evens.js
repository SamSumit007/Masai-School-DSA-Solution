if(one%2==0 && two%2==0)
{
    console.log("Yes");
}
else
{
    console.log("No");
}