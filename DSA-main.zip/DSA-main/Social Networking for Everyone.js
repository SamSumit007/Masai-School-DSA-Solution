if(age<13)
{
    console.log("1 Kms");
}
else if(age>=13 && age<18)
{
    console.log("5 Kms");
}
else if(age>=18 && age<30)
{
    console.log("10 Kms");
}
else
{
    console.log("You Can Have Friends From Anywhere");
}