const array =["Masai", "School"];

const output = array.map(function(element){
  return element[0];
});

console.log(output)