//age is given

if(age>=60)
{
    console.log("Senior Citizen");
}
else
{
    console.log("Not Senior Citizen");
}